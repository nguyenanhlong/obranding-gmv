# Bàn giao mock data — TOÀN BỘ 5 màn hình

Gói này để team BE thấy **FE đang kỳ vọng dữ liệu gì** ở cả 5 màn, kèm logic mock đang chạy
để đối chiếu công thức.

> Đây là **mock của FE**, không phải dữ liệu thật và không phải đặc tả BE.
> Đặc tả số liệu chính thức nằm ở artboard **M3 "Đặc tả số liệu"** trong Figma.
> Gói này chỉ chứng minh: với shape đó, FE đã dựng được toàn bộ màn hình.

## 5 màn và người phụ trách

| Màn | Route | Sample | Owner FE | Trạng thái mock |
|---|---|---|---|---|
| M1 Báo cáo tăng trưởng | `/growth` | `m1-growth-report.json` | Chinh (FE-A) | Chạy được |
| M2 Chi tiết kỳ | `/growth/period` | `m2-period-detail.json` | Long (FE-B) | Chạy được |
| M4 Chi tiết user | `/growth/customers/[id]` | `m4-buyer-detail.json` | Phuc (FE-C) | Chạy được |
| M5 Chi tiết nhà bán | `/growth/sellers/[id]` | `m5-seller-detail.json` | Phuc (FE-C) | Chạy được |
| M6 Chi tiết đơn | `/orders/[id]` | `m6-order-detail.json` | Long (FE-B) | Chạy được |

## Nên mở file nào trước

| Thứ tự | File | Để làm gì |
|---|---|---|
| 1 | `api-contract.md` | Bảng 5 endpoint + field + đơn vị + 3 điểm cần chốt |
| 2 | `samples/m2-period-detail.json` | Response phức tạp nhất (KPI + daily + bảng đơn) |
| 3 | `samples/m1-growth-report.json` | Response của hub (chuỗi 12 kỳ + top nhà bán) |
| 4 | `samples/m4-*.json`, `m5-*.json` | Hai màn drill-down còn lại |
| 5 | `reference/src/...` | Đọc logic mock nếu cần đối chiếu công thức |

## Cấu trúc

```
be-mock-all/
├─ README.md
├─ api-contract.md
├─ samples/
│  ├─ m1-growth-report.json      M1 — 12 kỳ + 4 KPI + top 3 nhà bán
│  ├─ m2-period-detail.json      M2 — 6 KPI + 30 ngày + 10 đơn
│  ├─ m4-buyer-detail.json       M4 — KPI user + giá trị theo tháng + top nhà bán
│  ├─ m5-seller-detail.json      M5 — KPI nhà bán + chuỗi theo tháng + đơn
│  ├─ m6-order-detail.json       M6 — 1 đơn: sản phẩm, ưu đãi, timeline
│  ├─ orders.100rows.csv         100 đơn mẫu, có BOM
│  └─ dataset-summary.json       5.952 đơn · 59 seller · phân bố trạng thái/tháng
└─ reference/src/
   ├─ contracts/base.ts                     OrderRow, Money, Delta, Period, Page
   ├─ platform/time.ts                      bucketOf, bucketRange, previousRange
   ├─ platform/reports/filters.ts           parseFilters (default 365 ngày, max 1096)
   ├─ platform/mock/dataset.ts              sinh dataset
   ├─ platform/mock/aggregate.ts            totalsOf, deltaOf, newBuyerRate, filterRange
   ├─ features/growth-overview/...          M1: contracts, mock, mapper
   ├─ features/period-detail/...            M2
   ├─ features/buyer-detail/...             M4
   ├─ features/seller-detail/...            M5
   └─ features/order-detail/...             M6
```

Trong `reference/`, dòng `import 'server-only'` đã được bỏ (package đó chỉ có trong Next),
nên đừng copy nguyên file về service khác.

## Quy ước FE đang dùng

| Quy ước | Giá trị |
|---|---|
| Đơn vị tiền | **integer VND**, không minor unit |
| Đơn vị đếm | **đơn con theo nhà bán** (`parent_order_id IS NOT NULL`) |
| Mốc thời gian | `placed_at`, kỳ `[00:00, 23:59:59]` giờ **UTC+7** |
| Phân trang | `page` **1-based**, `pageSize` ∈ {10, 20, 30} |
| Sort danh sách đơn | `placed_at` giảm dần |
| Loại khỏi KPI | `status = CANCELLED` |

## Những gì FE đã giả định (cần BE xác nhận)

1. **GMV** = `order_total` (sau ưu đãi, gồm phí ship).
2. **Đơn `NEEDS_RESOLUTION`** vẫn tính vào số đơn.
3. **User mua hàng** = `COUNT(DISTINCT customer_id)`, không cộng dồn từ ngày lên tháng.
4. **Tỉ lệ khách mới** dựa trên `MIN(placed_at)` toàn lịch sử của customer.
5. **Kỳ đang diễn ra**: FE hiển thị số thực tế, chưa dự phóng theo số ngày đã qua.
6. **M5 — Đơn/user** = số đơn / số user tham gia mua (không phải user của toàn hệ thống).

## Khi BE xong API

FE chỉ đổi biến môi trường, không sửa UI:

```bash
DATA_SOURCE=api
REPORT_API_BASE_URL=https://...
REPORT_API_TOKEN=...
```

Sau đó mỗi màn viết thêm file `*.http.ts` implement đúng interface trong `contracts.ts`.
Yêu cầu: **response khớp shape trong `samples/`** — thêm field thì được, đổi tên thì không.

## Điểm dễ lệch cần chốt trước khi code

| # | Vấn đề | Ảnh hưởng nếu lệch |
|---|---|---|
| 1 | Số tiền integer hay string | Mapper phải sửa; "1.145.300" → 1.1 tỷ thay vì 1.145 tỷ |
| 2 | Timezone của `placed_at` | Trả UTC thì mọi đơn sau 17:00 giờ VN bị lệch sang ngày hôm sau |
| 3 | `page` 1-based hay 0-based | Lệch 1 đơn vị là sai toàn bộ phân trang |
| 4 | Sort mặc định danh sách đơn | FE giả định mới nhất trước |
| 5 | Shape lỗi (4xx/5xx) | FE cần hiện `error.tsx` thay vì trắng trang |
