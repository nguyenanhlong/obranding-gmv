# Hợp đồng dữ liệu FE cần — 5 màn hình

Mọi endpoint dưới đây là **đề xuất** trong artboard "Đặc tả số liệu" (M3) của Figma, chưa có trong BE.
FE đang chạy mock với đúng shape này; sample thật nằm trong `samples/`.

Base path giả định `/admin/order-reports`, trừ M6 dùng `/admin/orders`.
Auth: service token giữa server FE và BE.

| Màn | Endpoint | Sample |
|---|---|---|
| M1 | `GET /growth` | `m1-growth-report.json` |
| M2 | `GET /growth/period` | `m2-period-detail.json` |
| M4 | `GET /growth/customers/:customerId` | `m4-buyer-detail.json` |
| M5 | `GET /growth/sellers/:sellerId` | `m5-seller-detail.json` |
| M6 | `GET /admin/orders/:publicId` | `m6-order-detail.json` |

---

## 1. M1 — Báo cáo tăng trưởng (hub)

```
GET /growth?period=month&dateFrom=2025-11-01&dateTo=2026-10-27&topN=3
```

```jsonc
{
  "period": "month",
  "range": { "from": "2025-11-01", "to": "2026-10-27" },
  "kpis": {
    "orders":  { "value": 5952, "delta": { "value": 421, "pct": 0.076, "direction": "up" } },
    "buyers":  { "value": 3398, "delta": { "...": "..." } },
    "gmv":     { "value": 25700000000, "delta": { "...": "..." },
                 "money": { "amount": 25700000000, "currency": "VND" } },
    "sellers": { "value": 59, "delta": { "...": "..." } }
  },
  "series": [
    { "bucket": "2025-11", "from": "2025-11-01", "to": "2025-11-30",
      "orders": 402, "gmv": 1730000000, "buyers": 318, "sellers": 40,
      "growthPct": null, "isCurrent": false }
  ],
  "topSellers": [
    { "sellerId": "seller-51", "sellerCode": "SL0001350",
      "sellerName": "TRẦM HƯƠNG KHÁNH HOÀ 5", "category": "Sở thích & sưu tầm",
      "orders": 130, "share": 0.0218,
      "gmv": { "amount": 61000000, "currency": "VND" }, "growthPct": 0.12 }
  ],
  "totalSellers": 59
}
```

Ghi chú:
- `series[].from` / `to` là khoảng ngày thực của bucket — FE dùng để drill-down sang M2.
- `growthPct` **null** khi kỳ trước = 0.
- `isCurrent` = bucket đang diễn ra → FE tô nhạt + nhãn "tạm tính".
- `topSellers[].share` là tỉ trọng trên tổng đơn của kỳ (0..1).

---

## 2. M2 — Chi tiết kỳ

```
GET /growth/period?dateFrom=2026-09-01&dateTo=2026-09-30
  &tab=orders|buyers|sellers&page=1&pageSize=10&q=&status=
```

```jsonc
{
  "range": { "from": "2026-09-01", "to": "2026-09-30" },
  "period": "day",
  "kpis": {
    "orders":  { "value": 557, "delta": { "value": 32, "pct": 0.0609, "direction": "up" } },
    "gmv":     { "value": 1145300820, "delta": { "...": "..." },
                 "money": { "amount": 1145300820, "currency": "VND" } },
    "buyers":  { "value": 309, "delta": { "...": "..." } },
    "sellers": { "value": 58, "delta": { "...": "..." } },
    "aov":     { "value": 2056195, "delta": { "...": "..." },
                 "money": { "amount": 2056195, "currency": "VND" } },
    "newBuyerRate": 0.291
  },
  "daily": [ { "date": "2026-09-01", "orders": 15 } ],
  "peak": { "date": "2026-09-09", "orders": 27 },
  "orders": { "items": [ /* OrderRow */ ], "total": 586, "page": 1, "pageSize": 10 }
}
```

Ghi chú:
- `daily` phủ **mọi ngày** trong kỳ, kể cả ngày 0 đơn.
- `orders.total` là tổng **sau khi lọc** `q`/`status`, không phải tổng kỳ.
- `peak` = ngày nhiều đơn nhất; `null` khi kỳ rỗng.

---

## 3. M4 — Chi tiết user

```
GET /growth/customers/:customerId?dateFrom=2026-09-01&dateTo=2026-09-30
```

```jsonc
{
  "customer": { "id": "customer-298", "name": "Vũ Gia Vinh",
                "phone": "090****818", "region": "Thành phố Hà Nội" },
  "range": { "from": "2026-09-01", "to": "2026-09-30" },
  "period": "day",
  "kpis": {
    "orders": 6,
    "totalValue": { "amount": 2637000, "currency": "VND" },
    "aov": { "amount": 439500, "currency": "VND" },
    "completionRate": 0.833,
    "sellerCount": 5,
    "lastOrderAt": "2026-09-28T14:02:11+07:00",
    "firstOrderAt": "2025-12-04T09:31:00+07:00"
  },
  "monthly": [ { "bucket": "2026-09", "amount": 2637000, "orders": 6 } ],
  "topSellers": [ { "sellerId": "seller-32", "sellerName": "MỘC HƯƠNG COSMETICS",
                    "orders": 2, "gmv": { "amount": 900000, "currency": "VND" } } ],
  "orders": { "items": [ /* OrderRow */ ], "total": 6, "page": 1, "pageSize": 10 },
  "totalValueDelta": { "value": 210000, "pct": 0.086, "direction": "up" }
}
```

Ghi chú: `completionRate` = `COMPLETED` / tổng đơn (gồm cả đơn huỷ ở mẫu số).
`monthly` chỉ tính đơn không huỷ.

---

## 4. M5 — Chi tiết nhà bán

```
GET /growth/sellers/:sellerId?dateFrom=2026-09-01&dateTo=2026-09-30&bucket=month
```

```jsonc
{
  "seller": { "id": "seller-22", "code": "SL0001154",
              "name": "CÔNG TY TNHH TRÀ TÂN CƯƠNG XANH", "category": "Thực phẩm & Đồ uống" },
  "range": { "from": "2026-09-01", "to": "2026-09-30" },
  "period": "day",
  "kpis": {
    "orders": 14,
    "gmv": { "amount": 29500000, "currency": "VND" },
    "buyers": 13,
    "aov": { "amount": 2107142, "currency": "VND" },
    "completionRate": 0.786,
    "ordersPerUser": 1.077
  },
  "monthly": [ { "bucket": "2026-09", "orders": 14, "gmv": 29500000, "buyers": 13 } ],
  "orders": { "items": [ /* OrderRow */ ], "total": 14, "page": 1, "pageSize": 10 }
}
```

Ghi chú: `ordersPerUser` = số đơn / số user tham gia mua (mức độ mua lặp lại).

---

## 5. M6 — Chi tiết đơn

```
GET /admin/orders/:publicId
```

`:publicId` là mã hiển thị (`2626093000005418AB`), **không phải** `id` nội bộ.

```jsonc
{
  "order": { /* OrderRow */ },
  "product": { "name": "Sản phẩm 54 của CÔNG", "sku": "1254-154",
               "unitPrice": 1609000, "quantity": 3 },
  "subTotal": 4827000,
  "shippingFee": 0,
  "totalDiscount": 193460,
  "total": { "amount": 4633540, "currency": "VND" },
  "timeline": [
    { "key": "placed",    "label": "Đặt hàng",        "at": "2026-09-30T22:15:14+07:00", "tone": "done" },
    { "key": "confirmed", "label": "Xác nhận",        "at": null, "tone": "pending" },
    { "key": "packed",    "label": "Đóng gói",        "at": null, "tone": "pending" },
    { "key": "shipped",   "label": "Gửi hàng",        "at": null, "tone": "pending" },
    { "key": "delivered", "label": "Giao thành công", "at": null, "tone": "pending" }
  ]
}
```

Mốc `cancelled` chỉ xuất hiện khi đơn bị huỷ. `at = null` = chưa xảy ra.

### Breakdown ưu đãi

FE hiển thị từ `order.discounts[]` (`{ label, amount }`), không tự tính lại tổng.

| Nhãn | Cột nguồn (theo M3 mục 4) |
|---|---|
| Thẻ Sành | `total_sanh_discount` (đã nằm trong `total_product_discount`) |
| Giảm giá SP | `total_direct_discount` |
| Voucher shop | `total_seller_discount` |
| Voucher sàn | `total_platform_discount` |
| Hỗ trợ ship | `total_shipping_discount` |

**Tổng ưu đãi** = product + seller + platform + shipping. **Không** cộng thêm Thẻ Sành lần nữa.

---

## 6. OrderRow — dùng chung cho M2, M4, M5, M6

```ts
type OrderRow = {
  id: string;
  publicId: string;       // mã hiển thị, dùng cho route /orders/:publicId
  placedAt: string;       // ISO 8601 kèm offset: 2026-09-30T22:15:14+07:00
  status: 'PENDING' | 'PREPARING' | 'COMPLETED' | 'CANCELLED' | 'NEEDS_RESOLUTION';
  sellerId: string;
  sellerCode: string;     // SL0001364
  sellerName: string;
  customerId: string;
  customerName: string;
  category: string;
  region: string;         // 'Thành phố Hà Nội' | 'Tỉnh Đồng Tháp' ...
  itemCount: number;
  payment: 'COD' | 'PREPAID';
  discounts: { label: string; amount: number }[];
  total: { amount: number; currency: 'VND' };
};
```

Nếu BE có thêm trạng thái đơn, báo trước để FE map nhãn hiển thị.

---

## 7. Ba điểm cần chốt trước khi BE code

1. **GMV**: `order_total` (sau ưu đãi, gồm ship — FE đang dùng) hay `sub_total` (trước ưu đãi)?
2. **Đơn `NEEDS_RESOLUTION` và RMA hoàn một phần** có tính vào số đơn không?
3. **Timezone**: `placed_at` trả UTC hay UTC+7? FE cắt `slice(0,10)` để lấy ngày.
